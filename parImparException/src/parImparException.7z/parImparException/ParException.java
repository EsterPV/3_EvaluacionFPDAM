package parImparException;

public class ParException extends Exception{

	public ParException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println("numero par");
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
}
