package parImparException;

public class ImparException extends Exception {

	public ImparException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println("numero impar");
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
